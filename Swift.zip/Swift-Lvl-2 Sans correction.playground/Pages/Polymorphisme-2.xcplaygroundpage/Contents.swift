//: [Previous](@previous)

import Foundation

//: # Le polymorphisme 2
//:
//: Pour comprendre le polymorphisme: un exemple simple à construire ensemble
//:



//: [Next](@next)
