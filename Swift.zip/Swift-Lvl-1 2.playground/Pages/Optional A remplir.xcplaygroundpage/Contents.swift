//: [Previous](@previous)

//: ---
//: ## Optional
//: ---

//: _Définition:_
//:
//: Un conteneur optionel signifie que son contenu __peut__ être nil (vide,NULL,null selon les langages)
//:
//: On le note avec un ? après son type
var chaineOptionelle: String?
chaineOptionelle = "texte"


// A compléter très largement en cours
//: [Next](@next)
